#include <stdio.h>

void cmp_hello(void)
{
        printf("Hello from example component!\n");
}