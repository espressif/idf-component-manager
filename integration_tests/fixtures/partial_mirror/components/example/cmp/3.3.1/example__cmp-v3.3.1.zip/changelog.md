## 3.3.5

- Fix function declaration isn't a prototype

## 3.3.4

- Fix function prototype

## 3.3.3

- Add use cases to the readme
- Add license
