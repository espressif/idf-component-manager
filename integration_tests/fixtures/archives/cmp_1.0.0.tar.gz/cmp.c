#include <stdio.h>

void cmp_hello()
{
        printf("Hello from CMP version 1.0.0\n");
}